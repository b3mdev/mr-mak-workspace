@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Atualizar Bento Workspace.ps1" %*
set "BENTO_EXIT=%ERRORLEVEL%"
if not "%BENTO_EXIT%"=="0" pause
exit /b %BENTO_EXIT%

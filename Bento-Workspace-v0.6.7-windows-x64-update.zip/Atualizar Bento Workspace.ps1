﻿[CmdletBinding()]
param([string]$InstallDirectory)
$ErrorActionPreference = 'Stop'

$payload = Join-Path $PSScriptRoot 'payload'
$package = Get-Content -Raw -LiteralPath (Join-Path $payload 'release.json') | ConvertFrom-Json
if ($package.release -notmatch '^bento-[0-9a-f]{12}$') { throw 'Pacote da Rede Bento invalido.' }

$registrations = @('HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*', 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*')
$entries = @(Get-ItemProperty -Path $registrations -ErrorAction SilentlyContinue | Where-Object { $_.DisplayName -in @('Bento Workspace','Mr. Mak Workspace') -and $_.InstallLocation })
if (-not $InstallDirectory) {
    $candidates = @($entries | ForEach-Object { $_.InstallLocation.Trim().Trim('"') })
    $candidates += @((Join-Path $env:LOCALAPPDATA 'Bento Workspace'),(Join-Path $env:LOCALAPPDATA 'Mr. Mak Workspace'))
    $installations = @($candidates | Where-Object { Test-Path -LiteralPath (Join-Path $_ 'mrmak-workspace.exe') } | ForEach-Object { (Resolve-Path -LiteralPath $_).Path } | Select-Object -Unique)
    if ($installations.Count -ne 1) { throw 'Indique a pasta da instalacao local com -InstallDirectory. Este pacote atualiza uma instalacao 0.6.6 existente.' }
    $InstallDirectory = $installations[0]
}
$install = (Resolve-Path -LiteralPath $InstallDirectory).Path
$app = (Resolve-Path -LiteralPath (Join-Path $install 'mrmak-workspace.exe')).Path
$service = (Resolve-Path -LiteralPath (Join-Path $install 'runtime/service')).Path
$main = Join-Path $service 'main.mjs'
$product = [Diagnostics.FileVersionInfo]::GetVersionInfo($app)
if ($product.ProductName -notin @('Bento Workspace','Mr. Mak Workspace') -or $product.ProductVersion -notmatch '^0\.6\.6(?:\.0)?$') { throw 'Este pacote corresponde ao Bento Workspace ou Mr. Mak Workspace 0.6.6.' }
if (-not (Test-Path -LiteralPath (Join-Path $service 'node_modules'))) { throw 'O runtime instalado esta incompleto.' }
$expected = [IO.File]::ReadAllText((Join-Path $payload 'service/package-lock.json')).Replace("`r`n", "`n")
$actual = [IO.File]::ReadAllText((Join-Path $service 'package-lock.json')).Replace("`r`n", "`n")
if ($expected -cne $actual) { throw 'As dependencias da instalacao sao de outra versao.' }

$launcher = @"
// Local Mr. Mak Workspace release entry point.
import { fileURLToPath } from 'node:url';
const ui = fileURLToPath(new URL('./releases/$($package.release)/ui/', import.meta.url));
const option = process.argv.indexOf('--ui', 2);
if (option < 0) process.argv.push('--ui', ui);
else process.argv[option + 1] = ui;
await import('./releases/$($package.release)/service/main.mjs');
"@
$raw = [IO.File]::ReadAllText($main)
if ($raw.Trim() -eq $launcher.Trim()) { Write-Output 'Bento Workspace 0.6.7 ja preparado.'; return }
if (-not $raw.StartsWith('// Local Mr. Mak Workspace release entry point.') -and -not $raw.Contains("from './server.mjs'")) { throw 'Entrada do runtime fora do formato deste instalador.' }

$releases = Join-Path $service 'releases'
New-Item -ItemType Directory -Path $releases -Force | Out-Null
$releases = (Resolve-Path -LiteralPath $releases).Path
if ((Split-Path -Parent $releases) -ne $service) { throw 'Pasta de atualizacoes invalida.' }
$destination = Join-Path $releases $package.release
if (-not (Test-Path -LiteralPath $destination)) {
    $temporaryRelease = Join-Path $releases ($package.release + '.' + [Guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $temporaryRelease | Out-Null
    Copy-Item -LiteralPath (Join-Path $payload 'service'),(Join-Path $payload 'ui'),(Join-Path $payload 'Bento Workspace.ico'),(Join-Path $payload 'release.json') -Destination $temporaryRelease -Recurse
    $sourceRelease = (Resolve-Path -LiteralPath $temporaryRelease).Path
    if ((Split-Path -Parent $sourceRelease) -ne $releases -or (Split-Path -Parent $destination) -ne $releases) { throw 'Destino da versao fora da pasta de atualizacoes.' }
    [IO.Directory]::Move($sourceRelease, $destination)
}
if ((Resolve-Path -LiteralPath $destination).Path -ne $destination) { throw 'Pasta da versao aponta para outro local.' }
foreach ($file in @('service/main.mjs','service/device-network.mjs','ui/index.html','Bento Workspace.ico','release.json')) {
    if (-not (Test-Path -LiteralPath (Join-Path $destination $file) -PathType Leaf)) { throw ('Pacote incompleto: ' + $file) }
}

$backup = Join-Path $env:LOCALAPPDATA ('BentoWorkspace-backups/' + $package.release + '-' + [Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $backup -Force | Out-Null
$pendingMain = Join-Path $service ($package.release + '.pending.mjs')
[IO.File]::WriteAllText($pendingMain, $launcher, [Text.UTF8Encoding]::new($false))
$oldApp = Join-Path $backup 'mrmak-workspace.exe'
$changedApp = $false
if ($product.ProductName -ne 'Bento Workspace') {
    $newApp = Join-Path $payload 'mrmak-workspace.exe'
    if (([Diagnostics.FileVersionInfo]::GetVersionInfo($newApp)).ProductName -ne 'Bento Workspace') { throw 'O executavel Bento do pacote e invalido.' }
    $pendingApp = Join-Path $install ($package.release + '.pending.exe')
    [IO.File]::Copy($newApp, $pendingApp, $true)
    [IO.File]::Replace($pendingApp, $app, $oldApp)
    $changedApp = $true
}
try { [IO.File]::Replace($pendingMain, $main, (Join-Path $backup 'main.mjs')) }
catch {
    if ($changedApp) { [IO.File]::Replace($oldApp, $app, (Join-Path $backup 'unapplied.exe')) }
    throw
}
if ([IO.File]::ReadAllText($main).Trim() -ne $launcher.Trim()) { throw 'Nao foi possivel verificar a entrada atualizada.' }
Write-Output 'Bento Workspace 0.6.7 preparado. A atualizacao aparece na proxima abertura completa do aplicativo.'

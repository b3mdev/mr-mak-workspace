import { readFile, writeFile, rename, mkdir, realpath, stat, unlink, open } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { randomBytes, timingSafeEqual } from 'node:crypto';

export const secret = () => randomBytes(32).toString('base64url');
export const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
export function equalSecret(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string') return false;
  const left = Buffer.from(a), right = Buffer.from(b);
  return left.length === right.length && timingSafeEqual(left, right);
}
export async function readJson(file, fallback) {
  try { return JSON.parse((await readFile(file, 'utf8')).replace(/^\uFEFF/, '')); } catch { return fallback; }
}
// Distinguishes a missing file, an unreadable file (error with a code) and
// invalid contents (error without a code), so state can be recovered instead of
// silently replaced by a fallback.
export async function readJsonFile(file) {
  let text;
  try { text = await readFile(file, 'utf8'); }
  catch (error) { return error.code === 'ENOENT' ? { missing: true } : { error }; }
  try { return { value: JSON.parse(text.replace(/^\uFEFF/, '')) }; } catch (error) { return { error }; }
}
const jsonSaves = new Map();
export async function saveJson(file, value, { beforeReplace } = {}) {
  const data = JSON.stringify(value, null, 2) + '\n';
  const resolved = path.resolve(file);
  const key = process.platform === 'win32' ? resolved.toLowerCase() : resolved;
  // A delayed retry must not overwrite a newer save to the same destination.
  const saving = (jsonSaves.get(key) || Promise.resolve()).catch(() => {}).then(() => writeJson(file, data, beforeReplace));
  jsonSaves.set(key, saving);
  try { await saving; }
  finally { if (jsonSaves.get(key) === saving) jsonSaves.delete(key); }
}
async function writeJson(file, data, beforeReplace) {
  await mkdir(path.dirname(file), { recursive: true });
  const temp = `${file}.${randomBytes(5).toString('hex')}.tmp`;
  try {
    // Flush the contents before the rename. Otherwise a power cut can keep the
    // rename but lose the data, leaving a zero-filled file in place of the old one.
    const handle = await open(temp, 'w', 0o600);
    try { await handle.writeFile(data); await handle.sync(); } finally { await handle.close(); }
    // Windows can briefly deny replacement while a reader or scanner holds the
    // destination. Keep the previous file intact and retry the atomic rename.
    for (let attempt = 0; ; attempt++) {
      try { await beforeReplace?.(); await rename(temp, file); break; }
      catch (error) {
        if (!['EPERM', 'EACCES', 'EBUSY'].includes(error.code) || attempt >= 5) throw error;
        await sleep(50 * 2 ** attempt);
      }
    }
  } finally {
    await unlink(temp).catch(() => {});
  }
}
// Typed folders such as `~/Projects` mean the home folder, not a `~` folder
// under the service's working directory. `~user` and inner `~` stay literal.
export const expandHome = value => typeof value === 'string' && (process.platform === 'win32' ? /^~(?=$|[\\/])/ : /^~(?=$|\/)/).test(value) ? path.join(os.homedir(), value.slice(1)) : value;
export const within = (root, file) => {
  const rel = path.relative(root, file);
  return rel === '' || (!rel.startsWith('..' + path.sep) && rel !== '..' && !path.isAbsolute(rel));
};
export async function realFile(root, relative = '') {
  const file = path.resolve(root, relative);
  if (!within(root, file)) throw Object.assign(new Error('Path is outside this location'), { status: 403 });
  const actual = await realpath(file);
  // A configured folder may itself be a junction. Resolve that root as well.
  if (!within(await realpath(root), actual)) throw Object.assign(new Error('Link leaves this location'), { status: 403 });
  return { file: actual, info: await stat(actual) };
}
export function json(response, status, value) {
  response.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  response.end(JSON.stringify(value));
}
export async function body(request, limit = 256 * 1024) {
  let length = 0;
  const chunks = [];
  for await (const chunk of request) {
    length += chunk.length;
    if (length > limit) throw Object.assign(new Error('Request is too large'), { status: 413 });
    chunks.push(chunk);
  }
  try { return JSON.parse(Buffer.concat(chunks).toString() || '{}'); }
  catch { throw Object.assign(new Error('Invalid JSON'), { status: 400 }); }
}
export function publicError(error) {
  // Errors from HTTP providers must never include request headers or environment values.
  return String(error?.message || 'Unexpected error').slice(0, 1500);
}

export const reportThemeCSS: string

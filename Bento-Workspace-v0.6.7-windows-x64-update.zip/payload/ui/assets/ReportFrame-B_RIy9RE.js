import{n as e,t}from"./jsx-runtime-DSZCEiL-.js";import{_ as n,g as r,y as i}from"./index-cbhkYING.js";var a=e(),o=n.filter(e=>e.id!==`dark`).map(e=>{let t=`html[data-mrmak-theme=`+e.id+`]:not([data-mak-theme=custom])`,n=t+`[data-mak-report=document]`,r={...i(e.id),"--bg":e.panel,"--card":e.raised,"--card2":e.bg,"--border":`var(--mak-border)`,"--muted":e.muted,"--card-glass":e.raised};return`
${t}{color-scheme:${e.scheme};background-color:${e.panel};color:${e.text}}
${t},${t} body,${t} body *{scrollbar-color:${e.muted} ${e.bg}!important;scrollbar-width:thin}
${t} ::-webkit-scrollbar-track,${t} ::-webkit-scrollbar-corner{background:${e.bg}!important}
${t} ::-webkit-scrollbar-thumb{background:${e.muted}!important;border-color:${e.bg}}
${n}{${Object.entries(r).map(([e,t])=>e+`:`+t+`!important`).join(`;`)}}
${n} body{background:${e.panel}!important;color:${e.text}!important}
${n} body::before{opacity:0!important}
${n} :is(h1,h2,h3,h4,strong,.card-title){color:var(--text-bright)!important;border-color:var(--mak-border)!important}
${n} :is(.meta,.subtitle,.sub,.muted,.eyebrow,.label,.card-desc,.var-label,.status,.stats small,em){color:${e.muted}!important}
${n} :is(.card,.mak-card,.obj-card,.verdict,.variant,.title-card,.kpi,main>section,main>header,main>figure){background:${e.raised}!important;border-color:var(--mak-border)!important;box-shadow:none!important}
${n} :is(a,code){color:${e.accent}!important}
${n} :is(pre,code,.flow,th){background:${e.bg}!important;border-color:var(--mak-border)!important}
${n} pre code{background:none!important}
${n} :is(th,td){color:${e.text}!important;border-color:var(--mak-border)!important}
${n} :is(button,select,summary){color:${e.text};border-color:var(--mak-border)}
${t} dialog.mak-lightbox{background:${e.bg};color:${e.text};border-color:${e.muted}}
${t} .mak-lightbox .mak-lightbox-toolbar{background:${e.panel};border-color:${e.muted}}
${t} .mak-lightbox .mak-lightbox-caption,${t} .mak-lightbox .mak-lightbox-note{color:${e.muted}}
${t} .mak-lightbox .mak-lightbox-toolbar :is(button,a){background:${e.raised}!important;color:${e.text}!important;border-color:${e.muted}}
`}).join(`
`),s=t(),c=`allow-scripts allow-same-origin allow-forms allow-popups allow-downloads`;function l({url:e,onLoad:t,...n}){let{resolved:i}=r(),c=(0,a.useRef)(null),[l]=(0,a.useState)(()=>{let t=new URL(e,location.href);return t.searchParams.set(`mrmak-theme`,i),t.href}),u=(0,a.useCallback)(()=>{let t=c.current;if(t){if(new URL(e,location.href).origin===location.origin)try{let e=t.contentDocument;if(e?.documentElement){if(!e.querySelector(`style[data-mrmak-report-theme]`)){let t=e.createElement(`style`);t.dataset.mrmakReportTheme=``,t.textContent=o,(e.head||e.documentElement).append(t)}e.documentElement.dataset.mrmakTheme=i}}catch{}t.contentWindow?.postMessage({type:`mrmak:theme`,theme:i},`*`)}},[i,e]);return(0,a.useEffect)(u,[u]),(0,s.jsx)(`iframe`,{...n,ref:c,src:l,onLoad:()=>{u(),t?.()}})}function u(e){return(0,s.jsx)(l,{...e},e.url)}export{u as n,c as t};